const KEY = "flipEnabled";
const PIP_KEY = "flipPiPEnabled";

let flipBtn, pipBtn;
let tabId;

document.addEventListener("DOMContentLoaded", async () => {
  flipBtn = document.getElementById("flipBtn");
  pipBtn = document.getElementById("pipBtn");

  const [tab] = await chrome.tabs.query({
    active: true,
    currentWindow: true
  });

  tabId = tab.id;
  init();
});

function init() {
  chrome.storage.local.get([KEY, PIP_KEY], (res) => {
    const map = res[KEY] || {};
    const pipMap = res[PIP_KEY] || {};

    const flipOn = map[tabId] || false;
    const pipOn = pipMap[tabId] || false;

    setActive(flipBtn, flipOn);
    setActive(pipBtn, pipOn);
  });

  flipBtn.addEventListener("click", async () => {
    const currentlyOn = flipBtn.classList.contains("active");
    const state = !currentlyOn;

    chrome.storage.local.get([KEY], async (res) => {
      const map = res[KEY] || {};
      map[tabId] = state;
      chrome.storage.local.set({ [KEY]: map });

      setActive(flipBtn, state);
      await inject();
    });
  });

  // PiP: inject + start/stop во ВСЕХ фреймах страницы
  pipBtn.addEventListener("click", async () => {
    const currentlyOn = pipBtn.classList.contains("active");
    const state = !currentlyOn;

    chrome.storage.local.get([PIP_KEY], async (res) => {
      const map = res[PIP_KEY] || {};
      map[tabId] = state;
      chrome.storage.local.set({ [PIP_KEY]: map });

      setActive(pipBtn, state);

      // 1. content.js во всех фреймах
      try {
        await chrome.scripting.executeScript({
          target: { tabId, allFrames: true },
          files: ["content.js"]
        });
      } catch (e) {}

      // 2. запуск / остановка PiP во всех фреймах
      // (сработает только в том, где реально есть video)
      try {
        await chrome.scripting.executeScript({
          target: { tabId, allFrames: true },
          func: (enabled) => {
            if (enabled) {
              window.startFlippedPiP?.();
            } else {
              document.exitPictureInPicture?.();
            }
          },
          args: [state]
        });
      } catch (e) {}
    });
  });

  [flipBtn, pipBtn].forEach((btn) => {
    btn.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        btn.click();
      }
    });
  });

  chrome.storage.onChanged.addListener((changes) => {
    if (changes[PIP_KEY]) {
      const newMap = changes[PIP_KEY].newValue || {};
      const newState = newMap[tabId] || false;
      if (pipBtn) setActive(pipBtn, newState);
    }
    if (changes[KEY]) {
      const newMap = changes[KEY].newValue || {};
      const newState = newMap[tabId] || false;
      if (flipBtn) setActive(flipBtn, newState);
    }
  });
}

function setActive(el, on) {
  if (on) el.classList.add("active");
  else el.classList.remove("active");
}

async function inject() {
  try {
    await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      files: ["content.js"]
    });
  } catch (e) {}
}
